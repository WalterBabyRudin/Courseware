#This is the tex file for week6 lecture
