#This is the tex file for week3 lecture
