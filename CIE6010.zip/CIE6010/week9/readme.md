#This is the tex file for week2 lecture
