#This is the tex file for week5 lecture
