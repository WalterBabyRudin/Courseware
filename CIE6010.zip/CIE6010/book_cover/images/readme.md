#This is the image for this book
