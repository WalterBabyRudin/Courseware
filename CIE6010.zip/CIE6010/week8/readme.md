#This is the tex file for week7 lecture
