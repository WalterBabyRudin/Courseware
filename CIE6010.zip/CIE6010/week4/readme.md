#This is the tex file for week4 lecture
